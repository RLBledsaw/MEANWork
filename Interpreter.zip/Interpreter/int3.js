var new_word;
function lastFunc(){
	new_word = 'old'
}
new_word = "NEW!"
console.log(new_word); //"NEW"